
testthat::test_that("Test join query", {
})