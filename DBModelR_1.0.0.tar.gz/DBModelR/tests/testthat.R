library(testthat)

test_check("DBModelR")
